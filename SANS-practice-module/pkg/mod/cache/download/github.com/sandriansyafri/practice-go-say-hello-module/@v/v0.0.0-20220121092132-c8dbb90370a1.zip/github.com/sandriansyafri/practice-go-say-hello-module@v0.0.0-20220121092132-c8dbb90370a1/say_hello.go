package go_say_hello_module

func SayHello(name string) string {
	return "Hello " + name
}
