package go_say_hello_module

func SayHello() string {
	return "Hello World!"
}
